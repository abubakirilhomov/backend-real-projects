const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  productName: {
    type: String,
    required: [true, "Product name is required"],
  },
  productType: {
    type: String,
    enum: ['CryptoCurrency', 'Company'], // Убедитесь, что значения соответствуют этим перечисленным значениям
    required: [true, "Product type is required"],
  },
  price: {
    type: Number,
    required: [true, "Product price is required"],
  },
  time: {
    type: Date,
    default: Date.now,
  },
});

const Product = mongoose.model('Product', productSchema);

module.exports = Product;
