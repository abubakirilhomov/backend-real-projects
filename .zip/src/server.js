const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const socketIo = require('socket.io');
require('dotenv').config();

// Import routes
const productRoutes = require('./routes/productRoutes');
const tradeRoutes = require('./routes/tradeRoutes');
const authRoutes = require('./routes/authRoutes');

// Initialize express
const app = express();

// Middleware
app.use(express.json());
app.use(cors({
  origin: 'http://localhost:5173', // Разрешите запросы только от вашего фронтенда
  methods: 'GET,POST,PUT,DELETE',
  allowedHeaders: 'Content-Type,Authorization'
}));

// Connect to MongoDB
const connectDB = require('./config/db');
const Product = require('./models/Product');
connectDB();

// Define routes
app.use('/api/products', productRoutes);
app.use('/api/trade', tradeRoutes);
app.use('/api/auth', authRoutes);

// Create server and integrate with socket.io
const server = require('http').createServer(app);
const io = socketIo(server, {
  cors: {
    origin: 'http://localhost:5173', // Разрешите запросы только от вашего фронтенда
    methods: ['GET', 'POST']
  }
});

// Handle socket.io connections
io.on('connection', (socket) => {
  console.log('New client connected');

  // Send initial product data to client
  const getProducts = async () => {
    try {
      const products = await Product.find();
      socket.emit('updateProducts', products);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  getProducts();
// Обновление цен продуктов каждые 5 секунд
setInterval(async () => {
  try {
    const products = await Product.find();
    products.forEach(async (product) => {
      // Обновление цены продукта
      product.price = Math.floor(Math.random() * 1000);
      await product.save();
    });
    // Отправка обновленных данных клиентам
    io.emit('updateProducts', await Product.find());
  } catch (error) {
    console.error('Error updating product prices:', error);
  }
}, 5000);
});

// Start server
const PORT = process.env.PORT || 8000;
server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
