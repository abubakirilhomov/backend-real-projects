const mongoose = require('mongoose');
const Product = require('./src/models/Product'); // Импортируем модель продукта
const connectDB = require('./src/config/db'); // Импортируем функцию подключения к MongoDB

connectDB(); // Подключаемся к базе данных

// Функция для генерации случайного значения
const getRandomPrice = () => Math.floor(Math.random() * (5000 - 100) + 100);

// Пример продуктов с разными типами и ценами
const products = [
  { productName: "Bitcoin", productType: "CryptoCurrency", price: getRandomPrice(), time: new Date() },
  { productName: "Ethereum", productType: "CryptoCurrency", price: getRandomPrice(), time: new Date() },
  { productName: "Apple Inc.", productType: "Company", price: getRandomPrice(), time: new Date() },
  { productName: "Tesla Inc.", productType: "Company", price: getRandomPrice(), time: new Date() },
  { productName: "Google LLC", productType: "Company", price: getRandomPrice(), time: new Date() },
  { productName: "Microsoft Corp.", productType: "Company", price: getRandomPrice(), time: new Date() },
  { productName: "Amazon.com Inc.", productType: "Company", price: getRandomPrice(), time: new Date() },
  { productName: "NVIDIA Corp.", productType: "Company", price: getRandomPrice(), time: new Date() },
  { productName: "Cardano", productType: "CryptoCurrency", price: getRandomPrice(), time: new Date() },
  { productName: "Polkadot", productType: "CryptoCurrency", price: getRandomPrice(), time: new Date() },
];

// Функция для создания продуктов
async function createProducts() {
  try {
    await Product.deleteMany(); // Очищаем коллекцию перед созданием
    for (const product of products) {
      const newProduct = new Product(product);
      await newProduct.save();
    }
    console.log("Продукты успешно созданы");
    process.exit(); // Завершаем выполнение скрипта
  } catch (error) {
    console.error("Ошибка при создании продуктов:", error);
    process.exit(1); // Завершаем выполнение с ошибкой
  }
}

createProducts();
